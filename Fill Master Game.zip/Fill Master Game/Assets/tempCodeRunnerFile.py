    y_offset = 200
    for line in mechanics:
        text = get_font(10).render(line, True, BLACK)
        screen.blit(text, (150, y_offset))
        y_offset += 50
